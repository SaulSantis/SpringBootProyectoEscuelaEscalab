package proyecto.escuela.escalab.ProyectoEscuelaEscalab.dto;

public class CursoDTO {

    private String nombre;
    private String jornada;

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getJornada() {
        return jornada;
    }

    public void setJornada(String jornada) {
        this.jornada = jornada;
    }
}
