package proyecto.escuela.escalab.ProyectoEscuelaEscalab.dto;

public class AsignaturaDTO {

    private String nombre;
    private String jornada;
    private String horario;

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getJornada() {
        return jornada;
    }

    public void setJornada(String jornada) {
        this.jornada = jornada;
    }

    public String getHorario() {
        return horario;
    }

    public void setHorario(String horario) {
        this.horario = horario;
    }
}
