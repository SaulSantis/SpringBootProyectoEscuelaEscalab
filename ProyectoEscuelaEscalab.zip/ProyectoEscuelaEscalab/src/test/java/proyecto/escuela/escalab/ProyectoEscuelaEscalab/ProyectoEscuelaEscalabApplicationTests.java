package proyecto.escuela.escalab.ProyectoEscuelaEscalab;

import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProyectoEscuelaEscalabApplicationTests {

//	@Test
//	void contextLoads() {
//	}

}
